globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/vQXgyiyMf2WW60Z4W6j95/_buildManifest.js",
    "static/vQXgyiyMf2WW60Z4W6j95/_ssgManifest.js",
    "static/vQXgyiyMf2WW60Z4W6j95/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3ll07n217cgxf.js",
    "static/chunks/0cbr67yte101v.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/turbopack-3rm-8hzemcm8b.js"
  ]
};
