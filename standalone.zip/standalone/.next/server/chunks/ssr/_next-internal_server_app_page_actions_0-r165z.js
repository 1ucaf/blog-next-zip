module.exports=[11893,a=>a.a(async(b,c)=>{try{var d=a.i(22918),e=b([d]);[d]=e.then?(await e)():e,a.s([]),c()}catch(a){c(a)}},!1),32989,a=>a.a(async(b,c)=>{try{var d=a.i(11893),e=a.i(22918),f=b([d,e]);[d,e]=f.then?(await f)():f,a.s(["408e2b99b3e9b5010b1972bb6c0a5f5810cdfb2248",()=>e.createPost]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=_next-internal_server_app_page_actions_0-r165z.js.map