1:"$Sreact.fragment"
8:I[68027,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default",1]
:HL["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","style"]
2:Tc34,
              (function() {
                var store = [];
                var runtimePush = null;

                // Función generadora de doble registro
                function makeDualPush(originalPush) {
                  return function(item) {
                    // 1. Registro Original (URL larga con query params para React Flight)
                    var res = originalPush.apply(this, arguments);

                    // 2. Registro Duplicado (Ruta relativa limpia para el Runtime de Turbopack)
                    try {
                      if (Array.isArray(item) && item[0] && typeof item[0].getAttribute === 'function') {
                        var src = item[0].getAttribute('src');
                        if (src && src.includes('api/assets?file=')) {
                          var url = new URL(src);
                          var fileParam = url.searchParams.get('file');
                          if (fileParam) {
                            // Normalizamos a formato relativo estricto
                            var cleanPath = fileParam;
                            if (cleanPath.indexOf('/_next/') === 0) cleanPath = cleanPath.substring(7);
                            else if (cleanPath.indexOf('_next/') === 0) cleanPath = cleanPath.substring(6);
                            if (cleanPath.indexOf('/') === 0) cleanPath = cleanPath.substring(1);

                            // Clonamos el elemento de script para enmascarar su lectura
                            var fakeScript = Object.create(item[0]);
                            fakeScript.getAttribute = function(name) {
                              return name === 'src' ? cleanPath : item[0].getAttribute(name);
                            };

                            // Construimos el par clonado con el mismo ID y factoría
                            var dualItem = [fakeScript];
                            for (var i = 1; i < item.length; i++) {
                              dualItem.push(item[i]);
                            }

                            // Lo empujamos al core del motor
                            originalPush.call(this, dualItem);
                          }
                        }
                      }
                    } catch(e) {}

                    return res;
                  };
                }

                // Interceptamos los elementos de la cola inicial
                store.push = makeDualPush(Array.prototype.push);

                // Monitoreamos el momento exacto en que el Runtimestandalone toma el control
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return store; },
                  set: function(val) {
                    if (val && typeof val.push === 'function' && val.push !== runtimePush) {
                      runtimePush = makeDualPush(val.push);
                      val.push = runtimePush;
                    }
                    store = val;
                  }
                });
              })();
            0:{"P":null,"c":["","_not-found"],"q":"","i":false,"f":[[["",{"children":["/_not-found",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",16],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","async":true,"nonce":"$undefined"}],["$","script","script-1",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"geist_a71539c9-module__T19VSG__variable geist_mono_8d43a2aa-module__8Li5zG__variable h-full antialiased","children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"$2"}}]}],"$L3"]}]]}],{"children":["$L4",{"children":["$L5",{},null,false,null]},null,false,"$@6"]},null,false,null],"$L7",false]],"m":"$undefined","G":["$8",["$L9"]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"gIxcQ2fI07RM3h86XrE7t"}
a:I[39756,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
b:I[37457,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
c:I[97367,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"OutletBoundary"]
d:"$Sreact.suspense"
10:I[97367,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"ViewportBoundary"]
12:I[97367,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"MetadataBoundary"]
3:["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$La",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Lb",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]
4:["$","$1","c",{"children":[null,["$","$La",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$Lb",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
5:["$","$1","c",{"children":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":"$3:props:children:props:notFound:0:1:props:style","children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":"$3:props:children:props:notFound:0:1:props:children:props:children:1:props:style","children":404}],["$","div",null,{"style":"$3:props:children:props:notFound:0:1:props:children:props:children:2:props:style","children":["$","h2",null,{"style":"$3:props:children:props:notFound:0:1:props:children:props:children:2:props:children:props:style","children":"This page could not be found."}]}]]}]}]],null,["$","$Lc",null,{"children":["$","$d",null,{"name":"Next.MetadataOutlet","children":"$@e"}]}]]}]
f:[]
6:"$Wf"
7:["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L10",null,{"children":"$L11"}],["$","div",null,{"hidden":true,"children":["$","$L12",null,{"children":["$","$d",null,{"name":"Next.Metadata","children":"$L13"}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}]
9:["$","link","0",{"rel":"stylesheet","href":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]
11:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
14:I[27201,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"IconMark"]
e:null
13:[["$","title","0",{"children":"Facundo Frosoni - Mi Blog"}],["$","meta","1",{"name":"description","content":"TP de Virtualización"}],["$","link","2",{"rel":"icon","href":"/41816709/api/assets?file=/favicon.ico"}],["$","$L14","3",{}]]
