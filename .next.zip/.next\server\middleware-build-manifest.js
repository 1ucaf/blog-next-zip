globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/eiVpjlQ799JCAhWAfTm9A/_buildManifest.js",
    "static/eiVpjlQ799JCAhWAfTm9A/_ssgManifest.js",
    "static/eiVpjlQ799JCAhWAfTm9A/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3ll07n217cgxf.js",
    "static/chunks/1ikgw17yr09rm.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/turbopack-0qfeifgbjevid.js"
  ]
};
