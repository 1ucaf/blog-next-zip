globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/GyKYcuQrdwhcBs1x5LNum/_buildManifest.js",
    "static/GyKYcuQrdwhcBs1x5LNum/_ssgManifest.js",
    "static/GyKYcuQrdwhcBs1x5LNum/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3ll07n217cgxf.js",
    "static/chunks/1ikgw17yr09rm.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/turbopack-3_2h7u8xefarz.js"
  ]
};
