globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/NJz9KGWGsh5BW6kg7L83q/_buildManifest.js",
    "static/NJz9KGWGsh5BW6kg7L83q/_ssgManifest.js",
    "static/NJz9KGWGsh5BW6kg7L83q/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3ll07n217cgxf.js",
    "static/chunks/1ikgw17yr09rm.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/turbopack-3_2h7u8xefarz.js"
  ]
};
