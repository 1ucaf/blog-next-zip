globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/O8STtfGkc6u-s0NKwLFwr/_buildManifest.js",
    "static/O8STtfGkc6u-s0NKwLFwr/_ssgManifest.js",
    "static/O8STtfGkc6u-s0NKwLFwr/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3ll07n217cgxf.js",
    "static/chunks/1ikgw17yr09rm.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/turbopack-0qfeifgbjevid.js"
  ]
};
