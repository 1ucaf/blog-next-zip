import Image from "next/image";
import pool from "@/lib/db";
import { DeployMarker } from "@/components/deploy-marker";
import { createPost } from "./actions";

export const dynamic = "force-dynamic";

type Post = {
  id: number;
  titulo: string;
  contenido: string;
  created_at: Date;
};

async function getPosts(): Promise<Post[]> {
  const { rows } = await pool.query<Post>(
    "SELECT id, titulo, contenido, created_at FROM posts ORDER BY created_at DESC",
  );
  return rows;
}

function formatDate(date: Date) {
  return new Intl.DateTimeFormat("es-AR", {
    dateStyle: "long",
    timeStyle: "short",
  }).format(new Date(date));
}

export default async function Home() {
  // const posts = await getPosts();

  return (
    <div className="min-h-full bg-gradient-to-b from-slate-50 via-white to-slate-100 text-slate-900">
      <DeployMarker />
      <div className="mx-auto flex w-full max-w-3xl flex-col gap-10 px-4 py-10 sm:px-6 sm:py-14">
        <header className="overflow-hidden rounded-3xl border border-slate-200/80 bg-white shadow-sm shadow-slate-200/60">
          <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-700 px-6 py-8 sm:px-8">
            <p className="text-sm font-medium tracking-[0.2em] text-slate-300 uppercase">
              Blog Personal
            </p>
            <h1 className="mt-2 text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Facundo Frosoni
            </h1>
            <p className="mt-2 text-slate-300">DNI 41.816.709</p>
          </div>

          <div className="flex flex-col gap-6 p-6 sm:flex-row sm:items-center sm:p-8">
            <div className="relative mx-auto h-32 w-32 shrink-0 overflow-hidden rounded-2xl border-4 border-white shadow-lg shadow-slate-300/40 sm:mx-0">
              <Image
                src="/41816709/foto.jpg"
                alt="Foto de Facundo Frosoni"
                fill
                className="object-cover"
                sizes="128px"
                priority
              />
            </div>

            <div className="flex flex-1 flex-col gap-4 text-center sm:text-left">
              <p className="text-slate-600">
                Espacio personal para compartir avances, notas y publicaciones
                del Trabajo Práctico Final.
              </p>
              <a
                href="/41816709/informe-tpf.pdf"
                download
                className="inline-flex items-center justify-center gap-2 self-center rounded-xl bg-slate-900 px-5 py-3 text-sm font-medium text-white transition hover:bg-slate-700 sm:self-start"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  className="h-4 w-4"
                  aria-hidden="true"
                >
                  <path d="M10.75 2.75a.75.75 0 0 0-1.5 0v8.614L6.295 8.235a.75.75 0 1 0-1.09 1.03l4.25 4.5a.75.75 0 0 0 1.09 0l4.25-4.5a.75.75 0 0 0-1.09-1.03l-2.955 3.129V2.75Z" />
                  <path d="M3.5 12.75a.75.75 0 0 0-1.5 0v2.5A2.75 2.75 0 0 0 4.75 18h10.5A2.75 2.75 0 0 0 18 15.25v-2.5a.75.75 0 0 0-1.5 0v2.5c0 .69-.56 1.25-1.25 1.25H4.75c-.69 0-1.25-.56-1.25-1.25v-2.5Z" />
                </svg>
                Descargar informe final (PDF)
              </a>
            </div>
          </div>
        </header>

        {/* <section className="rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm shadow-slate-200/60 sm:p-8">
          <div className="mb-6 flex items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-semibold tracking-tight">
                Publicaciones
              </h2>
              <p className="mt-1 text-sm text-slate-500">
                Ordenadas por fecha, más recientes primero.
              </p>
            </div>
            <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-600">
              {posts.length} {posts.length === 1 ? "entrada" : "entradas"}
            </span>
          </div>

          {posts.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 px-6 py-10 text-center">
              <p className="font-medium text-slate-700">
                Todavía no hay publicaciones.
              </p>
              <p className="mt-2 text-sm text-slate-500">
                Usá el formulario de abajo para agregar la primera.
              </p>
            </div>
          ) : (
            <ul className="space-y-4">
              {posts.map((post) => (
                <li
                  key={post.id}
                  className="rounded-2xl border border-slate-200 bg-slate-50/70 p-5 transition hover:border-slate-300 hover:bg-white"
                >
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                    <h3 className="text-lg font-semibold text-slate-900">
                      {post.titulo}
                    </h3>
                    <time
                      dateTime={new Date(post.created_at).toISOString()}
                      className="shrink-0 text-xs font-medium tracking-wide text-slate-500 uppercase"
                    >
                      {formatDate(post.created_at)}
                    </time>
                  </div>
                  <p className="mt-3 whitespace-pre-wrap text-slate-700">
                    {post.contenido}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </section> */}

        <section className="rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm shadow-slate-200/60 sm:p-8">
          <h2 className="text-2xl font-semibold tracking-tight">
            Nueva publicación
          </h2>
          <p className="mt-1 text-sm text-slate-500">
            El contenido se guarda en PostgreSQL y la página se actualiza al
            instante.
          </p>

          <form action={createPost} className="mt-6 space-y-4">
            <div>
              <label
                htmlFor="titulo"
                className="mb-2 block text-sm font-medium text-slate-700"
              >
                Título
              </label>
              <input
                id="titulo"
                name="titulo"
                type="text"
                required
                placeholder="Ej: Avance del proyecto"
                className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-slate-400 focus:ring-4 focus:ring-slate-200/70"
              />
            </div>

            <div>
              <label
                htmlFor="contenido"
                className="mb-2 block text-sm font-medium text-slate-700"
              >
                Contenido
              </label>
              <textarea
                id="contenido"
                name="contenido"
                required
                rows={5}
                placeholder="Escribí el detalle de la publicación..."
                className="w-full resize-y rounded-xl border border-slate-200 bg-white px-4 py-3 text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-slate-400 focus:ring-4 focus:ring-slate-200/70"
              />
            </div>

            <button
              type="submit"
              className="inline-flex w-full items-center justify-center rounded-xl bg-slate-900 px-5 py-3 text-sm font-medium text-white transition hover:bg-slate-700 sm:w-auto"
            >
              Publicar
            </button>
          </form>
        </section>
      </div>
    </div>
  );
}
