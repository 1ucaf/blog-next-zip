import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                var currentTurbopack = [];

                // Función central para normalizar la identidad del script antes de que la lea Turbopack
                function interceptPush(originalPush) {
                  return function(item) {
                    if (Array.isArray(item) && item[0] && typeof item[0].getAttribute === 'function') {
                      var realSrc = item[0].getAttribute('src');
                      if (realSrc && realSrc.includes('api/assets?file=')) {
                        try {
                          var url = new URL(realSrc);
                          var fileParam = url.searchParams.get('file');
                          if (fileParam) {
                            // Extraemos el path relativo eliminando el prefijo '_next/' de forma segura
                            var cleanPath = fileParam;
                            if (cleanPath.indexOf('/_next/') === 0) cleanPath = cleanPath.substring(7);
                            else if (cleanPath.indexOf('_next/') === 0) cleanPath = cleanPath.substring(6);
                            if (cleanPath.indexOf('/') === 0) cleanPath = cleanPath.substring(1);

                            // Clonamos el elemento de script y enmascaramos getAttribute para Turbopack
                            var fakeScript = Object.create(item[0]);
                            fakeScript.getAttribute = function(name) {
                              return name === 'src' ? cleanPath : item[0].getAttribute(name);
                            };

                            item[0] = fakeScript;
                          }
                        } catch(e) {}
                      }
                    }
                    return originalPush.apply(this, arguments);
                  };
                }

                // Acoplamos el interceptor a la cola inicial
                currentTurbopack.push = interceptPush(Array.prototype.push);

                // Definimos la propiedad global permitiendo que el Runtime tome el control de forma interactiva
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() {
                    return currentTurbopack;
                  },
                  set: function(val) {
                    if (val && typeof val.push === 'function') {
                      // El runtime de Next.js tomó el control: envolvemos su despachador nativo
                      val.push = interceptPush(val.push);
                    }
                    currentTurbopack = val;
                  }
                });
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}