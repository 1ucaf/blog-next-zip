import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                var targetArray = [];
                var originalRuntimePush = null;

                var handler = {
                  get: function(target, prop) {
                    if (prop === 'push') {
                      return function(item) {
                        // Interceptamos el registro del chunk
                        if (Array.isArray(item) && item[0] && item[0].src) {
                          var src = item[0].src;
                          if (src.includes('api/assets?file=')) {
                            try {
                              var url = new URL(src);
                              var realFile = url.searchParams.get('file');
                              if (realFile) {
                                // Reconstruimos la URL limpia que Next.js/Turbopack espera internamente
                                var realSrc = window.location.origin + (realFile.startsWith('/') ? '' : '/') + realFile;
                                
                                // Clonamos el elemento de script original pero enmascaramos su .src
                                var fakeScript = Object.create(item[0]);
                                Object.defineProperty(fakeScript, 'src', { value: realSrc, enumerable: true });
                                fakeScript.getAttribute = function(name) {
                                  return name === 'src' ? realSrc : item[0].getAttribute(name);
                                };
                                
                                // Reemplazamos el script real por nuestro clon limpio antes de que lo vea Turbopack
                                item[0] = fakeScript;
                              }
                            } catch(e) {}
                          }
                        }
                        // Pasamos el chunk modificado al array original o al runtime de Next si ya inició
                        return originalRuntimePush ? originalRuntimePush(item) : targetArray.push(item);
                      };
                    }
                    return targetArray[prop];
                  },
                  set: function(target, prop, value) {
                    if (prop === 'push') {
                      // Captura cuando el runtime de Next.js standalone intenta tomar el control del .push
                      originalRuntimePush = value;
                      return true;
                    }
                    targetArray[prop] = value;
                    return true;
                  }
                };

                // Inicializamos el Proxy global fulminante
                var proxy = new Proxy(targetArray, handler);
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return proxy; },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { proxy.push(x); });
                    }
                  }
                });
              })();
            `,
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  );
}