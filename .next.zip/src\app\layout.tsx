import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                window._flightLogs = [];
                
                // 1. Espía pasivo para la cola de TURBOPACK
                var targetArray = [];
                var originalRuntimePush = null;
                var turbopackHandler = {
                  get: function(target, prop) {
                    if (prop === 'push') {
                      return function(item) {
                        window._flightLogs.push({
                          timestamp: performance.now(),
                          tipo: 'TURBOPACK.push',
                          argumentos: item ? item.length : 0,
                          scriptSrc: item && item[0] && typeof item[0] === 'object' ? item[0].getAttribute('src') : String(item && item[0]),
                          ids: item ? Array.from(item).slice(1).filter(x => typeof x !== 'function') : []
                        });
                        return originalRuntimePush ? originalRuntimePush(item) : targetArray.push(item);
                      };
                    }
                    return targetArray[prop];
                  },
                  set: function(target, prop, value) {
                    if (prop === 'push') {
                      originalRuntimePush = value;
                      return true;
                    }
                    targetArray[prop] = value;
                    return true;
                  }
                };
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return new Proxy(targetArray, turbopackHandler); },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { globalThis.TURBOPACK.push(x); });
                    }
                  }
                });

                // 2. Espía pasivo para la cola de streaming __next_f
                var nextFArray = [];
                var nextFHandler = {
                  get: function(target, prop) {
                    if (prop === 'push') {
                      return function(item) {
                        window._flightLogs.push({
                          timestamp: performance.now(),
                          tipo: '__next_f.push',
                          contenidoCorto: JSON.stringify(item).slice(0, 80)
                        });
                        return nextFArray.push(item);
                      };
                    }
                    return nextFArray[prop];
                  },
                  set: function(target, prop, value) {
                    nextFArray[prop] = value;
                    return true;
                  }
                };
                Object.defineProperty(window, '__next_f', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return new Proxy(nextFArray, nextFHandler); },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { window.__next_f.push(x); });
                    }
                  }
                });
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}