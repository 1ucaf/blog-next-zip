import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                var store = [];
                var runtimePush = null;

                // Función generadora de doble registro
                function makeDualPush(originalPush) {
                  return function(item) {
                    // 1. Registro Original (URL larga con query params para React Flight)
                    var res = originalPush.apply(this, arguments);

                    // 2. Registro Duplicado (Ruta relativa limpia para el Runtime de Turbopack)
                    try {
                      if (Array.isArray(item) && item[0] && typeof item[0].getAttribute === 'function') {
                        var src = item[0].getAttribute('src');
                        if (src && src.includes('api/assets?file=')) {
                          var url = new URL(src);
                          var fileParam = url.searchParams.get('file');
                          if (fileParam) {
                            // Normalizamos a formato relativo estricto
                            var cleanPath = fileParam;
                            if (cleanPath.indexOf('/_next/') === 0) cleanPath = cleanPath.substring(7);
                            else if (cleanPath.indexOf('_next/') === 0) cleanPath = cleanPath.substring(6);
                            if (cleanPath.indexOf('/') === 0) cleanPath = cleanPath.substring(1);

                            // Clonamos el elemento de script para enmascarar su lectura
                            var fakeScript = Object.create(item[0]);
                            fakeScript.getAttribute = function(name) {
                              return name === 'src' ? cleanPath : item[0].getAttribute(name);
                            };

                            // Construimos el par clonado con el mismo ID y factoría
                            var dualItem = [fakeScript];
                            for (var i = 1; i < item.length; i++) {
                              dualItem.push(item[i]);
                            }

                            // Lo empujamos al core del motor
                            originalPush.call(this, dualItem);
                          }
                        }
                      }
                    } catch(e) {}

                    return res;
                  };
                }

                // Interceptamos los elementos de la cola inicial
                store.push = makeDualPush(Array.prototype.push);

                // Monitoreamos el momento exacto en que el Runtimestandalone toma el control
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return store; },
                  set: function(val) {
                    if (val && typeof val.push === 'function' && val.push !== runtimePush) {
                      runtimePush = makeDualPush(val.push);
                      val.push = runtimePush;
                    }
                    store = val;
                  }
                });
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}