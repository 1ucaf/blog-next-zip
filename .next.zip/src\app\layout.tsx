import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                var store = [];
                var runtimePush = null;

                // Modificador quirúrgico: convierte los paths relativos de Turbopack en las URLs de la API
                function patchRuntimeManifest(item) {
                  if (Array.isArray(item) && item.length === 2 && item[1] && Array.isArray(item[1].otherChunks)) {
                    item[1].otherChunks = item[1].otherChunks.map(function(chunkPath) {
                      if (chunkPath.indexOf('api/assets') === -1) {
                        return 'https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/' + chunkPath;
                      }
                      return chunkPath;
                    });
                  }
                }

                // Monitorear la cola inicial de carga
                var originalArrayPush = Array.prototype.push;
                store.push = function(item) {
                  patchRuntimeManifest(item);
                  return originalArrayPush.apply(this, arguments);
                };

                // Monitorear el momento en que Next.js toma el control global
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return store; },
                  set: function(val) {
                    if (val && typeof val.push === 'function' && val.push !== runtimePush) {
                      runtimePush = val.push;
                      val.push = function(item) {
                        patchRuntimeManifest(item);
                        return runtimePush.apply(this, arguments);
                      };
                    }
                    if (Array.isArray(val)) {
                      val.forEach(patchRuntimeManifest);
                    }
                    store = val;
                  }
                });
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}