import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                window._flightLogs = [];
                var targetArray = [];
                var originalRuntimePush = null;

                var turbopackHandler = {
                  get: function(target, prop) {
                    if (prop === 'push') {
                      return function(item) {
                        var logEntry = {
                          timestamp: performance.now(),
                          tipo: 'TURBOPACK.push',
                          rutaOriginal: null,
                          rutaNormalizada: null,
                          statusPush: 'Pendiente',
                          error: null
                        };

                        if (Array.isArray(item) && item[0]) {
                          if (typeof item[0].getAttribute === 'function') {
                            logEntry.rutaOriginal = item[0].getAttribute('src');
                            
                            if (logEntry.rutaOriginal && logEntry.rutaOriginal.includes('api/assets?file=')) {
                              try {
                                var url = new URL(logEntry.rutaOriginal);
                                var fileParam = url.searchParams.get('file');
                                if (fileParam) {
                                  // Normalización experimental
                                  var cleanPath = fileParam.replace(/^\\/?_next\\//, '');
                                  logEntry.rutaNormalizada = cleanPath;

                                  // Clonamos el elemento de script
                                  var fakeScript = Object.create(item[0]);
                                  fakeScript.getAttribute = function(name) {
                                    return name === 'src' ? cleanPath : item[0].getAttribute(name);
                                  };
                                  
                                  // Aplicamos el cambiazo
                                  item[0] = fakeScript;
                                }
                              } catch(e) {
                                logEntry.error = 'Error en parseo: ' + e.message;
                              }
                            }
                          } else {
                            logEntry.rutaOriginal = 'No es un elemento Script (Posible config/runtime)';
                          }
                        }

                        window._flightLogs.push(logEntry);

                        // Ejecutar el push real y capturar si explota por dentro
                        try {
                          var resultado = originalRuntimePush ? originalRuntimePush(item) : targetArray.push(item);
                          logEntry.statusPush = originalRuntimePush ? 'Procesado por Runtime' : 'Guardado en Cola Inicial';
                          return resultado;
                        } catch(pushError) {
                          logEntry.statusPush = 'CRASHED 💥';
                          logEntry.error = pushError.message;
                          console.error('⚠️ Turbopack nativo rechazó el item:', pushError);
                          throw pushError;
                        }
                      };
                    }
                    return targetArray[prop];
                  },
                  set: function(target, prop, value) {
                    if (prop === 'push') {
                      originalRuntimePush = value;
                      return true;
                    }
                    targetArray[prop] = value;
                    return true;
                  }
                };

                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return new Proxy(targetArray, turbopackHandler); },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { globalThis.TURBOPACK.push(x); });
                    }
                  }
                });
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}