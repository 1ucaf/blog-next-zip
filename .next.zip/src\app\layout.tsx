import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                // 1. Interceptar propiedad .src nativa de los Scripts
                const srcDescriptor = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
                
                Object.defineProperty(HTMLScriptElement.prototype, 'src', {
                  configurable: true,
                  enumerable: true,
                  get: function() {
                    const realSrc = srcDescriptor.get.call(this);
                    // Si Turbopack lee la URL de la API, le devolvemos el espejismo de la ruta limpia
                    if (realSrc && realSrc.includes('api/assets?file=')) {
                      try {
                        const url = new URL(realSrc);
                        const fileParam = url.searchParams.get('file');
                        if (fileParam) {
                          return window.location.origin + (fileParam.startsWith('/') ? '' : '/') + fileParam;
                        }
                      } catch(e) {}
                    }
                    return realSrc;
                  },
                  set: function(val) {
                    // Si Next.js escribe un nuevo script dinámico limpio, lo camuflamos para el proxy
                    let targetVal = val;
                    if (typeof val === 'string' && val.includes('_next/static/') && !val.includes('api/assets')) {
                      try {
                        const url = new URL(val.startsWith('http') ? val : window.location.origin + val);
                        targetVal = window.location.origin + '/41816709/api/assets?file=' + url.pathname + url.search;
                      } catch(e) {}
                    }
                    srcDescriptor.set.call(this, targetVal);
                  }
                });

                // 2. Interceptar getAttribute y setAttribute para consistencia absoluta de Turbopack
                const originalGet = HTMLScriptElement.prototype.getAttribute;
                HTMLScriptElement.prototype.getAttribute = function(name) {
                  if (name === 'src') {
                    const val = originalGet.call(this, 'src');
                    if (val && val.includes('api/assets?file=')) {
                      try {
                        const abs = val.startsWith('http') ? val : window.location.origin + val;
                        return new URL(abs).searchParams.get('file');
                      } catch(e) {}
                    }
                  }
                  return originalGet.call(this, name);
                };

                const originalSet = HTMLScriptElement.prototype.setAttribute;
                HTMLScriptElement.prototype.setAttribute = function(name, val) {
                  let targetVal = val;
                  if (name === 'src' && typeof val === 'string' && val.includes('_next/static/') && !val.includes('api/assets')) {
                    try {
                      const url = new URL(val.startsWith('http') ? val : window.location.origin + val);
                      targetVal = '/41816709/api/assets?file=' + url.pathname + url.search;
                    } catch(e) {}
                  }
                  originalSet.call(this, name, targetVal);
                };
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}