import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                // 1. Extractor universal a formato relativo estricto (e.g., "static/chunks/xxx.js")
                function toRelativePath(urlStr) {
                  if (!urlStr || typeof urlStr !== 'string') return urlStr;
                  if (urlStr.includes('api/assets?file=')) {
                    try {
                      var url = new URL(urlStr.startsWith('http') ? urlStr : window.location.origin + urlStr);
                      var fileParam = url.searchParams.get('file');
                      if (fileParam) {
                        var p = fileParam;
                        if (p.indexOf('/_next/') === 0) p = p.substring(7);
                        else if (p.indexOf('_next/') === 0) p = p.substring(6);
                        if (p.indexOf('/') === 0) p = p.substring(1);
                        return p;
                      }
                    } catch(e) {}
                  }
                  return urlStr;
                }

                // 2. Normalizar getAttribute('src') para que Turbopack lea el path relativo nativo
                var origGetAttribute = HTMLScriptElement.prototype.getAttribute;
                HTMLScriptElement.prototype.getAttribute = function(name) {
                  var val = origGetAttribute.call(this, name);
                  return (name === 'src' && val) ? toRelativePath(val) : val;
                };

                // 3. Interceptar asignaciones dinámicas de scripts futuros (evita 501 en lazy loading)
                var srcDescriptor = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
                Object.defineProperty(HTMLScriptElement.prototype, 'src', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return srcDescriptor.get.call(this); },
                  set: function(val) {
                    var targetVal = val;
                    if (typeof val === 'string' && val.includes('_next/static/') && !val.includes('api/assets')) {
                      try {
                        var urlObj = new URL(val.startsWith('http') ? val : window.location.origin + val);
                        targetVal = window.location.origin + '/41816709/api/assets?file=' + urlObj.pathname + urlObj.search;
                      } catch (e) {}
                    }
                    srcDescriptor.set.call(this, targetVal);
                  }
                });

                // 4. Normalizar el stream de React Flight (__next_f) al formato relativo exacto
                var realNextF = window.__next_f || [];
                function cleanPayload(item) {
                  if (Array.isArray(item) && typeof item[1] === 'string') {
                    var searchLong = 'https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/';
                    var searchRel = '/41816709/api/assets?file=/_next/';
                    item[1] = item[1].split(searchLong).join('');
                    item[1] = item[1].split(searchRel).join('');
                  }
                  return item;
                }

                if (Array.isArray(realNextF)) {
                  for (var i = 0; i < realNextF.length; i++) {
                    cleanPayload(realNextF[i]);
                  }
                }

                var origNextFPush = realNextF.push || Array.prototype.push;
                realNextF.push = function(item) {
                  return origNextFPush.call(this, cleanPayload(item));
                };

                Object.defineProperty(window, '__next_f', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return realNextF; },
                  set: function(val) {
                    if (val && typeof val.push === 'function') {
                      var nativePush = val.push;
                      val.push = function(x) { return nativePush.call(this, cleanPayload(x)); };
                    }
                    realNextF = val;
                  }
                });
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full flex flex-col">
        {children}
      </body>
    </html>
  );
}