import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                // 1. Alinear el Lado de Turbopack: Normalizar la lectura de getAttribute('src')
                var origGetAttribute = HTMLScriptElement.prototype.getAttribute;
                HTMLScriptElement.prototype.getAttribute = function(name) {
                  var val = origGetAttribute.call(this, name);
                  if (name === 'src' && val && val.includes('api/assets?file=')) {
                    try {
                      var url = new URL(val.startsWith('http') ? val : window.location.origin + val);
                      var fileParam = url.searchParams.get('file');
                      if (fileParam) {
                        var cleanPath = fileParam;
                        if (cleanPath.indexOf('/_next/') === 0) cleanPath = cleanPath.substring(7);
                        else if (cleanPath.indexOf('_next/') === 0) cleanPath = cleanPath.substring(6);
                        if (cleanPath.indexOf('/') === 0) cleanPath = cleanPath.substring(1);
                        return cleanPath; // Devuelve 'static/chunks/xxx.js'
                      }
                    } catch(e) {}
                  }
                  return val;
                };

                // 2. Alinear el Lado de React: Interceptar el stream de __next_f antes de que se procese
                var realNextF = [];
                Object.defineProperty(window, '__next_f', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return realNextF; },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(item) { realNextF.push(item); });
                    }
                  }
                });

                var originalNextFPush = realNextF.push;
                realNextF.push = function(item) {
                  if (Array.isArray(item) && typeof item[1] === 'string') {
                    // Reemplazamos la URL absoluta larga por el path relativo limpio
                    item[1] = item[1].split('https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/').join('');
                    item[1] = item[1].split('https://nap.frt.utn.edu.ar/41816709/api/assets?file=').join('');
                  }
                  return originalNextFPush.apply(this, arguments);
                };
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}