import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                var OriginalURL = globalThis.URL;
                function CustomURL(url, base) {
                  // Si Next.js intenta resolver rutas usando nuestro assetPrefix de la API
                  if (typeof base === 'string' && base.includes('api/assets?file=')) {
                    var cleanUrl = url.startsWith('/') ? url : '/' + url;
                    // Forzamos la concatenación manual para que no destruya el query parameter
                    return new OriginalURL(base + cleanUrl);
                  }
                  return new OriginalURL(url, base);
                }
                CustomURL.prototype = OriginalURL.prototype;
                Object.setPrototypeOf(CustomURL, OriginalURL);
                globalThis.URL = CustomURL;
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}