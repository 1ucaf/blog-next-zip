import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                var targetArray = [];
                var originalRuntimePush = null;

                var turbopackHandler = {
                  get: function(target, prop) {
                    if (prop === 'push') {
                      return function(item) {
                        // Interceptamos el chunk antes de que entre al core de Turbopack
                        if (Array.isArray(item) && item[0] && typeof item[0].getAttribute === 'function') {
                          var realSrc = item[0].getAttribute('src');
                          if (realSrc && realSrc.includes('api/assets?file=')) {
                            try {
                              var url = new URL(realSrc);
                              var fileParam = url.searchParams.get('file');
                              if (fileParam) {
                                // Normalizamos la ruta quitando la barra inicial y el prefijo '_next/'
                                // Ejemplo: '/_next/static/chunks/xxx.js' -> 'static/chunks/xxx.js'
                                var cleanPath = fileParam.replace(/^\\/?_next\\//, '');
                                
                                // Creamos un clon virtualizado del elemento script
                                var fakeScript = Object.create(item[0]);
                                fakeScript.getAttribute = function(name) {
                                  return name === 'src' ? cleanPath : item[0].getAttribute(name);
                                };
                                
                                // Sobrescribimos el argumento con nuestra identidad normalizada
                                item[0] = fakeScript;
                              }
                            } catch(e) {}
                          }
                        }
                        return originalRuntimePush ? originalRuntimePush(item) : targetArray.push(item);
                      };
                    }
                    return targetArray[prop];
                  },
                  set: function(target, prop, value) {
                    if (prop === 'push') {
                      originalRuntimePush = value;
                      return true;
                    }
                    targetArray[prop] = value;
                    return true;
                  }
                };

                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return new Proxy(targetArray, turbopackHandler); },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { globalThis.TURBOPACK.push(x); });
                    }
                  }
                });
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}