import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: 'Facundo Frosoni - Mi Blog',
  description: 'TP de Virtualización',
  icons: {
    icon: '/41816709/api/assets?file=/favicon.ico',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                // 1. Convertidor universal: Transforma URLs de la API en paths oficiales limpios de Next.js
                function virtualizeUrl(urlStr) {
                  if (!urlStr || typeof urlStr !== 'string') return urlStr;
                  if (urlStr.includes('api/assets?file=')) {
                    try {
                      var urlObj = new URL(urlStr.startsWith('http') ? urlStr : window.location.origin + urlStr);
                      var fileParam = urlObj.searchParams.get('file');
                      if (fileParam) {
                        if (fileParam.indexOf('/') !== 0) fileParam = '/' + fileParam;
                        return window.location.origin + '/41816709' + fileParam;
                      }
                    } catch (e) {}
                  }
                  return urlStr;
                }

                // 2. Virtualizar Prototipos del DOM (Engaña por completo a Turbopack)
                var origGetAttribute = HTMLScriptElement.prototype.getAttribute;
                HTMLScriptElement.prototype.getAttribute = function(name) {
                  var val = origGetAttribute.call(this, name);
                  return (name === 'src' && val) ? virtualizeUrl(val) : val;
                };

                var srcDescriptor = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
                Object.defineProperty(HTMLScriptElement.prototype, 'src', {
                  configurable: true,
                  enumerable: true,
                  get: function() {
                    return virtualizeUrl(srcDescriptor.get.call(this));
                  },
                  set: function(val) {
                    // Si Next.js inyecta chunks dinámicos limpios, los camuflamos para el proxy de la facultad
                    var targetVal = val;
                    if (typeof val === 'string' && val.includes('_next/static/') && !val.includes('api/assets')) {
                      try {
                        var urlObj = new URL(val.startsWith('http') ? val : window.location.origin + val);
                        targetVal = window.location.origin + '/41816709/api/assets?file=' + urlObj.pathname + urlObj.search;
                      } catch (e) {}
                    }
                    srcDescriptor.set.call(this, targetVal);
                  }
                });

                // 3. Virtualizar el flujo de Hydración (Engaña por completo a React Flight)
                function cleanPayload(item) {
                  if (Array.isArray(item) && typeof item[1] === 'string') {
                    var targetStr = item[1];
                    var searchStr = 'https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/';
                    while (targetStr.indexOf(searchStr) !== -1) {
                      targetStr = targetStr.split(searchStr).join('https://nap.frt.utn.edu.ar/41816709/_next/');
                    }
                    var searchStrRel = '/41816709/api/assets?file=/_next/';
                    while (targetStr.indexOf(searchStrRel) !== -1) {
                      targetStr = targetStr.split(searchStrRel).join('/41816709/_next/');
                    }
                    item[1] = targetStr;
                  }
                  return item;
                }

                var assignedNextF = window.__next_f || [];
                var originalNextFPush = Array.prototype.push;

                if (Array.isArray(assignedNextF)) {
                  for (var i = 0; i < assignedNextF.length; i++) {
                    cleanPayload(assignedNextF[i]);
                  }
                }

                assignedNextF.push = function(item) {
                  return originalNextFPush.call(this, cleanPayload(item));
                };

                Object.defineProperty(window, '__next_f', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return assignedNextF; },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { assignedNextF.push(x); });
                    } else if (val && typeof val.push === 'function') {
                      var origValidPush = val.push;
                      val.push = function(x) {
                        return origValidPush.call(this, cleanPayload(x));
                      };
                    }
                    assignedNextF = val;
                  }
                });
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-full flex flex-col">
        {children}
      </body>
    </html>
  );
}