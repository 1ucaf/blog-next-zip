import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ file: string[] }> }
) {
  // En Next.js 15/16 params es una Promesa, la resolvemos con await
  const resolvedParams = await params;
  const fileArray = resolvedParams.file;

  if (!fileArray || fileArray.length === 0) {
    return new NextResponse('Missing file path', { status: 400 });
  }

  // Reconstruimos la ruta relativa uniendo el array (ej: ["_next", "static", "chunks", "xxx.js"])
  const filePathUrl = fileArray.join('/');

  // 🛡️ Validación de seguridad estricta
  const isStatic = filePathUrl.startsWith('_next/static/');
  const isFavicon = filePathUrl === 'favicon.ico';

  if (!isStatic && !isFavicon) {
    return new NextResponse('Unauthorized path', { status: 403 });
  }

  // Resolver la localización física real en el disco del contenedor
  let filePath = '';
  if (isStatic) {
    // Cambiamos el prefijo '_next' por '.next' para mapear el directorio del standalone
    const diskPath = filePathUrl.replace('_next/', '.next/');
    filePath = path.join(process.cwd(), diskPath);
  } else if (isFavicon) {
    filePath = path.join(process.cwd(), 'public', 'favicon.ico');
  }

  if (!fs.existsSync(filePath)) {
    return new NextResponse('File not found', { status: 404 });
  }

  const fileBuffer = fs.readFileSync(filePath);

  // Mapeo dinámico y estricto de cabeceras MIME
  let contentType = 'text/plain';
  if (filePathUrl.endsWith('.js')) contentType = 'application/javascript';
  else if (filePathUrl.endsWith('.css')) contentType = 'text/css';
  else if (filePathUrl.endsWith('.woff2')) contentType = 'font/woff2';
  else if (filePathUrl.endsWith('.ico')) contentType = 'image/x-icon';

  return new NextResponse(fileBuffer, {
    headers: {
      'Content-Type': contentType,
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  });
}