module.exports=[11893,a=>a.a(async(b,c)=>{try{var d=a.i(22918),e=b([d]);[d]=e.then?(await e)():e,a.s([]),c()}catch(a){c(a)}},!1),32989,a=>a.a(async(b,c)=>{try{var d=a.i(11893),e=a.i(22918),f=b([d,e]);[d,e]=f.then?(await f)():f,a.s(["4094a791b1a40ef693f6725e2e8320cb454cc8726e",()=>e.createPost]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=_next-internal_server_app_page_actions_0-r165z.js.map