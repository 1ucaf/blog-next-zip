var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/assets/route.js")
R.c("server/chunks/[externals]__16ywbif._.js")
R.c("server/chunks/[root-of-the-server]__1--ck9r._.js")
R.c("server/chunks/_next-internal_server_app_api_assets_route_actions_1qb_ukn.js")
R.m(81169)
module.exports=R.m(81169).exports
