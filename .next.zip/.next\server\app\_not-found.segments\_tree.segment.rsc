:HL["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/0t9_7th8yv50v.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"1RbPCF0BtYLseOpQkwrzh"}
