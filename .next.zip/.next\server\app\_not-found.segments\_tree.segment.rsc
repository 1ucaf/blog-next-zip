:HL["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"cPRuo1BKT2hkk4CnEDcd2"}
