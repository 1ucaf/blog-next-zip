1:"$Sreact.fragment"
4:I[39756,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
5:I[37457,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
:HL["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","style"]
2:T11d2,
              (function() {
                // 1. Convertidor universal: Transforma URLs de la API en paths oficiales limpios de Next.js
                function virtualizeUrl(urlStr) {
                  if (!urlStr || typeof urlStr !== 'string') return urlStr;
                  if (urlStr.includes('api/assets?file=')) {
                    try {
                      var urlObj = new URL(urlStr.startsWith('http') ? urlStr : window.location.origin + urlStr);
                      var fileParam = urlObj.searchParams.get('file');
                      if (fileParam) {
                        if (fileParam.indexOf('/') !== 0) fileParam = '/' + fileParam;
                        return window.location.origin + '/41816709' + fileParam;
                      }
                    } catch (e) {}
                  }
                  return urlStr;
                }

                // 2. Virtualizar Prototipos del DOM (Engaña por completo a Turbopack)
                var origGetAttribute = HTMLScriptElement.prototype.getAttribute;
                HTMLScriptElement.prototype.getAttribute = function(name) {
                  var val = origGetAttribute.call(this, name);
                  return (name === 'src' && val) ? virtualizeUrl(val) : val;
                };

                var srcDescriptor = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
                Object.defineProperty(HTMLScriptElement.prototype, 'src', {
                  configurable: true,
                  enumerable: true,
                  get: function() {
                    return virtualizeUrl(srcDescriptor.get.call(this));
                  },
                  set: function(val) {
                    // Si Next.js inyecta chunks dinámicos limpios, los camuflamos para el proxy de la facultad
                    var targetVal = val;
                    if (typeof val === 'string' && val.includes('_next/static/') && !val.includes('api/assets')) {
                      try {
                        var urlObj = new URL(val.startsWith('http') ? val : window.location.origin + val);
                        targetVal = window.location.origin + '/41816709/api/assets?file=' + urlObj.pathname + urlObj.search;
                      } catch (e) {}
                    }
                    srcDescriptor.set.call(this, targetVal);
                  }
                });

                // 3. Virtualizar el flujo de Hydración (Engaña por completo a React Flight)
                function cleanPayload(item) {
                  if (Array.isArray(item) && typeof item[1] === 'string') {
                    var targetStr = item[1];
                    var searchStr = 'https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/';
                    while (targetStr.indexOf(searchStr) !== -1) {
                      targetStr = targetStr.split(searchStr).join('https://nap.frt.utn.edu.ar/41816709/_next/');
                    }
                    var searchStrRel = '/41816709/api/assets?file=/_next/';
                    while (targetStr.indexOf(searchStrRel) !== -1) {
                      targetStr = targetStr.split(searchStrRel).join('/41816709/_next/');
                    }
                    item[1] = targetStr;
                  }
                  return item;
                }

                var assignedNextF = window.__next_f || [];
                var originalNextFPush = Array.prototype.push;

                if (Array.isArray(assignedNextF)) {
                  for (var i = 0; i < assignedNextF.length; i++) {
                    cleanPayload(assignedNextF[i]);
                  }
                }

                assignedNextF.push = function(item) {
                  return originalNextFPush.call(this, cleanPayload(item));
                };

                Object.defineProperty(window, '__next_f', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return assignedNextF; },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { assignedNextF.push(x); });
                    } else if (val && typeof val.push === 'function') {
                      var origValidPush = val.push;
                      val.push = function(x) {
                        return origValidPush.call(this, cleanPayload(x));
                      };
                    }
                    assignedNextF = val;
                  }
                });
              })();
            0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","precedence":"next"}],["$","script","script-0",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","async":true}],["$","script","script-1",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js","async":true}]],["$","html",null,{"lang":"en","className":"geist_a71539c9-module__T19VSG__variable geist_mono_8d43a2aa-module__8Li5zG__variable h-full antialiased","children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"$2"}}]}],"$L3"]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"B4nQI1JC8eCLuIJNPx7Hn"}
3:["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]}]
