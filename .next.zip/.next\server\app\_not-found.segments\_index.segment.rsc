1:"$Sreact.fragment"
3:I[39756,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
4:I[37457,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
:HL["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","style"]
2:T969,
              (function() {
                // 1. Alinear el Lado de Turbopack: Normalizar la lectura de getAttribute('src')
                var origGetAttribute = HTMLScriptElement.prototype.getAttribute;
                HTMLScriptElement.prototype.getAttribute = function(name) {
                  var val = origGetAttribute.call(this, name);
                  if (name === 'src' && val && val.includes('api/assets?file=')) {
                    try {
                      var url = new URL(val.startsWith('http') ? val : window.location.origin + val);
                      var fileParam = url.searchParams.get('file');
                      if (fileParam) {
                        var cleanPath = fileParam;
                        if (cleanPath.indexOf('/_next/') === 0) cleanPath = cleanPath.substring(7);
                        else if (cleanPath.indexOf('_next/') === 0) cleanPath = cleanPath.substring(6);
                        if (cleanPath.indexOf('/') === 0) cleanPath = cleanPath.substring(1);
                        return cleanPath; // Devuelve 'static/chunks/xxx.js'
                      }
                    } catch(e) {}
                  }
                  return val;
                };

                // 2. Alinear el Lado de React: Interceptar el stream de __next_f antes de que se procese
                var realNextF = [];
                Object.defineProperty(window, '__next_f', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return realNextF; },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(item) { realNextF.push(item); });
                    }
                  }
                });

                var originalNextFPush = realNextF.push;
                realNextF.push = function(item) {
                  if (Array.isArray(item) && typeof item[1] === 'string') {
                    // Reemplazamos la URL absoluta larga por el path relativo limpio
                    item[1] = item[1].split('https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/').join('');
                    item[1] = item[1].split('https://nap.frt.utn.edu.ar/41816709/api/assets?file=').join('');
                  }
                  return originalNextFPush.apply(this, arguments);
                };
              })();
            0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","precedence":"next"}],["$","script","script-0",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","async":true}],["$","script","script-1",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js","async":true}]],["$","html",null,{"lang":"en","className":"geist_a71539c9-module__T19VSG__variable geist_mono_8d43a2aa-module__8Li5zG__variable h-full antialiased","children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"$2"}}]}],["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":"$L5"}]],[]]}]}]]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"NTBtOrC8xBHjXxyKp4xRH"}
5:["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]
