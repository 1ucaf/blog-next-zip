1:"$Sreact.fragment"
4:I[39756,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
5:I[37457,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
:HL["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","style"]
2:Tc34,
              (function() {
                var store = [];
                var runtimePush = null;

                // Función generadora de doble registro
                function makeDualPush(originalPush) {
                  return function(item) {
                    // 1. Registro Original (URL larga con query params para React Flight)
                    var res = originalPush.apply(this, arguments);

                    // 2. Registro Duplicado (Ruta relativa limpia para el Runtime de Turbopack)
                    try {
                      if (Array.isArray(item) && item[0] && typeof item[0].getAttribute === 'function') {
                        var src = item[0].getAttribute('src');
                        if (src && src.includes('api/assets?file=')) {
                          var url = new URL(src);
                          var fileParam = url.searchParams.get('file');
                          if (fileParam) {
                            // Normalizamos a formato relativo estricto
                            var cleanPath = fileParam;
                            if (cleanPath.indexOf('/_next/') === 0) cleanPath = cleanPath.substring(7);
                            else if (cleanPath.indexOf('_next/') === 0) cleanPath = cleanPath.substring(6);
                            if (cleanPath.indexOf('/') === 0) cleanPath = cleanPath.substring(1);

                            // Clonamos el elemento de script para enmascarar su lectura
                            var fakeScript = Object.create(item[0]);
                            fakeScript.getAttribute = function(name) {
                              return name === 'src' ? cleanPath : item[0].getAttribute(name);
                            };

                            // Construimos el par clonado con el mismo ID y factoría
                            var dualItem = [fakeScript];
                            for (var i = 1; i < item.length; i++) {
                              dualItem.push(item[i]);
                            }

                            // Lo empujamos al core del motor
                            originalPush.call(this, dualItem);
                          }
                        }
                      }
                    } catch(e) {}

                    return res;
                  };
                }

                // Interceptamos los elementos de la cola inicial
                store.push = makeDualPush(Array.prototype.push);

                // Monitoreamos el momento exacto en que el Runtimestandalone toma el control
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return store; },
                  set: function(val) {
                    if (val && typeof val.push === 'function' && val.push !== runtimePush) {
                      runtimePush = makeDualPush(val.push);
                      val.push = runtimePush;
                    }
                    store = val;
                  }
                });
              })();
            0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","precedence":"next"}],["$","script","script-0",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","async":true}],["$","script","script-1",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js","async":true}]],["$","html",null,{"lang":"en","className":"geist_a71539c9-module__T19VSG__variable geist_mono_8d43a2aa-module__8Li5zG__variable h-full antialiased","children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"$2"}}]}],"$L3"]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"gIxcQ2fI07RM3h86XrE7t"}
3:["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]}]
