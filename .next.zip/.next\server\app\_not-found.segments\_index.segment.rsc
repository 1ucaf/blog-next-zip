1:"$Sreact.fragment"
4:I[39756,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
5:I[37457,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
:HL["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","style"]
2:T1040,
              (function() {
                window._flightLogs = [];
                var targetArray = [];
                var originalRuntimePush = null;

                var turbopackHandler = {
                  get: function(target, prop) {
                    if (prop === 'push') {
                      return function(item) {
                        var logEntry = {
                          timestamp: performance.now(),
                          tipo: 'TURBOPACK.push',
                          rutaOriginal: null,
                          rutaNormalizada: null,
                          statusPush: 'Pendiente',
                          error: null
                        };

                        if (Array.isArray(item) && item[0]) {
                          if (typeof item[0].getAttribute === 'function') {
                            logEntry.rutaOriginal = item[0].getAttribute('src');
                            
                            if (logEntry.rutaOriginal && logEntry.rutaOriginal.includes('api/assets?file=')) {
                              try {
                                var url = new URL(logEntry.rutaOriginal);
                                var fileParam = url.searchParams.get('file');
                                if (fileParam) {
                                  // Normalización experimental
                                  var cleanPath = fileParam.replace(/^\/?_next\//, '');
                                  logEntry.rutaNormalizada = cleanPath;

                                  // Clonamos el elemento de script
                                  var fakeScript = Object.create(item[0]);
                                  fakeScript.getAttribute = function(name) {
                                    return name === 'src' ? cleanPath : item[0].getAttribute(name);
                                  };
                                  
                                  // Aplicamos el cambiazo
                                  item[0] = fakeScript;
                                }
                              } catch(e) {
                                logEntry.error = 'Error en parseo: ' + e.message;
                              }
                            }
                          } else {
                            logEntry.rutaOriginal = 'No es un elemento Script (Posible config/runtime)';
                          }
                        }

                        window._flightLogs.push(logEntry);

                        // Ejecutar el push real y capturar si explota por dentro
                        try {
                          var resultado = originalRuntimePush ? originalRuntimePush(item) : targetArray.push(item);
                          logEntry.statusPush = originalRuntimePush ? 'Procesado por Runtime' : 'Guardado en Cola Inicial';
                          return resultado;
                        } catch(pushError) {
                          logEntry.statusPush = 'CRASHED 💥';
                          logEntry.error = pushError.message;
                          console.error('⚠️ Turbopack nativo rechazó el item:', pushError);
                          throw pushError;
                        }
                      };
                    }
                    return targetArray[prop];
                  },
                  set: function(target, prop, value) {
                    if (prop === 'push') {
                      originalRuntimePush = value;
                      return true;
                    }
                    targetArray[prop] = value;
                    return true;
                  }
                };

                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return new Proxy(targetArray, turbopackHandler); },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { globalThis.TURBOPACK.push(x); });
                    }
                  }
                });
              })();
            0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3406jdsgp_iml.css","precedence":"next"}],["$","script","script-0",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","async":true}],["$","script","script-1",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js","async":true}]],["$","html",null,{"lang":"en","className":"geist_a71539c9-module__T19VSG__variable geist_mono_8d43a2aa-module__8Li5zG__variable h-full antialiased","children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"$2"}}]}],"$L3"]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"fpDCQFkZfq5Rpp12oMb_h"}
3:["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]}]
