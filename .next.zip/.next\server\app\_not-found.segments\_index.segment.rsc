1:"$Sreact.fragment"
4:I[39756,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
5:I[37457,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
:HL["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3esw8-58rsnhu.css","style"]
2:Tc50,
              (function() {
                var targetArray = [];
                var originalRuntimePush = null;

                var handler = {
                  get: function(target, prop) {
                    if (prop === 'push') {
                      return function(item) {
                        // Interceptamos el registro del chunk
                        if (Array.isArray(item) && item[0] && item[0].src) {
                          var src = item[0].src;
                          if (src.includes('api/assets?file=')) {
                            try {
                              var url = new URL(src);
                              var realFile = url.searchParams.get('file');
                              if (realFile) {
                                // Reconstruimos la URL limpia que Next.js/Turbopack espera internamente
                                var realSrc = window.location.origin + (realFile.startsWith('/') ? '' : '/') + realFile;
                                
                                // Clonamos el elemento de script original pero enmascaramos su .src
                                var fakeScript = Object.create(item[0]);
                                Object.defineProperty(fakeScript, 'src', { value: realSrc, enumerable: true });
                                fakeScript.getAttribute = function(name) {
                                  return name === 'src' ? realSrc : item[0].getAttribute(name);
                                };
                                
                                // Reemplazamos el script real por nuestro clon limpio antes de que lo vea Turbopack
                                item[0] = fakeScript;
                              }
                            } catch(e) {}
                          }
                        }
                        // Pasamos el chunk modificado al array original o al runtime de Next si ya inició
                        return originalRuntimePush ? originalRuntimePush(item) : targetArray.push(item);
                      };
                    }
                    return targetArray[prop];
                  },
                  set: function(target, prop, value) {
                    if (prop === 'push') {
                      // Captura cuando el runtime de Next.js standalone intenta tomar el control del .push
                      originalRuntimePush = value;
                      return true;
                    }
                    targetArray[prop] = value;
                    return true;
                  }
                };

                // Inicializamos el Proxy global fulminante
                var proxy = new Proxy(targetArray, handler);
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return proxy; },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { proxy.push(x); });
                    }
                  }
                });
              })();
            0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/3esw8-58rsnhu.css","precedence":"next"}],["$","script","script-0",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","async":true}],["$","script","script-1",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js","async":true}]],["$","html",null,{"lang":"es","children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"$2"}}]}],"$L3"]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"bx_RrfdbyxcG8kZnkf2QQ"}
3:["$","body",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]}]
