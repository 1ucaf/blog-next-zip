1:"$Sreact.fragment"
4:I[39756,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
5:I[37457,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"default"]
:HL["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/0t9_7th8yv50v.css","style"]
2:Tce5,
              (function() {
                // 1. Interceptar propiedad .src nativa de los Scripts
                const srcDescriptor = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
                
                Object.defineProperty(HTMLScriptElement.prototype, 'src', {
                  configurable: true,
                  enumerable: true,
                  get: function() {
                    const realSrc = srcDescriptor.get.call(this);
                    // Si Turbopack lee la URL de la API, le devolvemos el espejismo de la ruta limpia
                    if (realSrc && realSrc.includes('api/assets?file=')) {
                      try {
                        const url = new URL(realSrc);
                        const fileParam = url.searchParams.get('file');
                        if (fileParam) {
                          return window.location.origin + (fileParam.startsWith('/') ? '' : '/') + fileParam;
                        }
                      } catch(e) {}
                    }
                    return realSrc;
                  },
                  set: function(val) {
                    // Si Next.js escribe un nuevo script dinámico limpio, lo camuflamos para el proxy
                    let targetVal = val;
                    if (typeof val === 'string' && val.includes('_next/static/') && !val.includes('api/assets')) {
                      try {
                        const url = new URL(val.startsWith('http') ? val : window.location.origin + val);
                        targetVal = window.location.origin + '/41816709/api/assets?file=' + url.pathname + url.search;
                      } catch(e) {}
                    }
                    srcDescriptor.set.call(this, targetVal);
                  }
                });

                // 2. Interceptar getAttribute y setAttribute para consistencia absoluta de Turbopack
                const originalGet = HTMLScriptElement.prototype.getAttribute;
                HTMLScriptElement.prototype.getAttribute = function(name) {
                  if (name === 'src') {
                    const val = originalGet.call(this, 'src');
                    if (val && val.includes('api/assets?file=')) {
                      try {
                        const abs = val.startsWith('http') ? val : window.location.origin + val;
                        return new URL(abs).searchParams.get('file');
                      } catch(e) {}
                    }
                  }
                  return originalGet.call(this, name);
                };

                const originalSet = HTMLScriptElement.prototype.setAttribute;
                HTMLScriptElement.prototype.setAttribute = function(name, val) {
                  let targetVal = val;
                  if (name === 'src' && typeof val === 'string' && val.includes('_next/static/') && !val.includes('api/assets')) {
                    try {
                      const url = new URL(val.startsWith('http') ? val : window.location.origin + val);
                      targetVal = '/41816709/api/assets?file=' + url.pathname + url.search;
                    } catch(e) {}
                  }
                  originalSet.call(this, name, targetVal);
                };
              })();
            0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/0t9_7th8yv50v.css","precedence":"next"}],["$","script","script-0",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","async":true}],["$","script","script-1",{"src":"https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js","async":true}]],["$","html",null,{"lang":"en","className":"geist_a71539c9-module__T19VSG__variable geist_mono_8d43a2aa-module__8Li5zG__variable h-full antialiased","children":[["$","head",null,{"children":["$","script",null,{"dangerouslySetInnerHTML":{"__html":"$2"}}]}],"$L3"]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"5moUPywbpk4Xc9zbcw26z"}
3:["$","body",null,{"className":"min-h-full flex flex-col","children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]]}]}]
