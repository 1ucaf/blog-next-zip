"use client";

import { useEffect } from "react";

// Cambiá este string en cada prueba de deploy para verificar que llegó la nueva versión.
const DEPLOY_MARKER = "deploy-test-2";

export function DeployMarker() {
  useEffect(() => {
    console.log(`[blog-next] ${DEPLOY_MARKER} — página cargada en el cliente`);
  }, []);

  return (
    <div>
      <p style={{ color: 'red', fontSize: '50px', fontWeight: 'bold' }}>Deploy Marker</p>
      <button className="bg-red-500 text-white p-2 rounded-md cursor-pointer transition-all duration-300 hover:bg-blue-800" onClick={() => {
        console.log('Button clicked');
      }}>Click me</button>
    </div>
  );
}
