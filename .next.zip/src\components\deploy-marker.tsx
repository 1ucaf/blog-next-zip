"use client";

import { useEffect } from "react";

// Cambiá este string en cada prueba de deploy para verificar que llegó la nueva versión.
const DEPLOY_MARKER = "deploy-test-2";

export function DeployMarker() {
  useEffect(() => {
    console.log(`[blog-next] ${DEPLOY_MARKER} — página cargada en el cliente`);
  }, []);

  return <p style={{ color: 'red', fontSize: '50px', fontWeight: 'bold' }}>Deploy Marker</p>;
}
