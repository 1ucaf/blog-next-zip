var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/assets/[...file]/route.js")
R.c("server/chunks/[externals]__16ywbif._.js")
R.c("server/chunks/[root-of-the-server]__16s21i5._.js")
R.c("server/chunks/_next-internal_server_app_api_assets_[___file]_route_actions_1u44ptp.js")
R.m(81754)
module.exports=R.m(81754).exports
