"use server";

import { revalidatePath } from "next/cache";
import pool from "@/lib/db";
import { redirect } from "next/navigation";

export async function createPost(formData: FormData) {
  const titulo = formData.get("titulo")?.toString().trim();
  const contenido = formData.get("contenido")?.toString().trim();

  if (!titulo || !contenido) {
    return;
  }

  await pool.query(
    "INSERT INTO posts (titulo, contenido) VALUES ($1, $2)",
    [titulo, contenido],
  );

  revalidatePath("/");
  redirect("/41816709");
}
