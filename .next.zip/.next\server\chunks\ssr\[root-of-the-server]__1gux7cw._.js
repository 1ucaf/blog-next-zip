module.exports=[89578,a=>{a.v({className:"geist_a71539c9-module__T19VSG__className",variable:"geist_a71539c9-module__T19VSG__variable"})},35214,a=>{a.v({className:"geist_mono_8d43a2aa-module__8Li5zG__className",variable:"geist_mono_8d43a2aa-module__8Li5zG__variable"})},27572,a=>{"use strict";var b=a.i(7997),c=a.i(89578);let d={className:c.default.className,style:{fontFamily:"'Geist', 'Geist Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(35214);let f={className:e.default.className,style:{fontFamily:"'Geist Mono', 'Geist Mono Fallback'",fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable),a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"en",className:`${d.variable} ${f.variable} h-full antialiased`,children:[(0,b.jsx)("head",{children:(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:`
              (function() {
                var store = [];
                var runtimePush = null;

                // Funci\xf3n generadora de doble registro
                function makeDualPush(originalPush) {
                  return function(item) {
                    // 1. Registro Original (URL larga con query params para React Flight)
                    var res = originalPush.apply(this, arguments);

                    // 2. Registro Duplicado (Ruta relativa limpia para el Runtime de Turbopack)
                    try {
                      if (Array.isArray(item) && item[0] && typeof item[0].getAttribute === 'function') {
                        var src = item[0].getAttribute('src');
                        if (src && src.includes('api/assets?file=')) {
                          var url = new URL(src);
                          var fileParam = url.searchParams.get('file');
                          if (fileParam) {
                            // Normalizamos a formato relativo estricto
                            var cleanPath = fileParam;
                            if (cleanPath.indexOf('/_next/') === 0) cleanPath = cleanPath.substring(7);
                            else if (cleanPath.indexOf('_next/') === 0) cleanPath = cleanPath.substring(6);
                            if (cleanPath.indexOf('/') === 0) cleanPath = cleanPath.substring(1);

                            // Clonamos el elemento de script para enmascarar su lectura
                            var fakeScript = Object.create(item[0]);
                            fakeScript.getAttribute = function(name) {
                              return name === 'src' ? cleanPath : item[0].getAttribute(name);
                            };

                            // Construimos el par clonado con el mismo ID y factor\xeda
                            var dualItem = [fakeScript];
                            for (var i = 1; i < item.length; i++) {
                              dualItem.push(item[i]);
                            }

                            // Lo empujamos al core del motor
                            originalPush.call(this, dualItem);
                          }
                        }
                      }
                    } catch(e) {}

                    return res;
                  };
                }

                // Interceptamos los elementos de la cola inicial
                store.push = makeDualPush(Array.prototype.push);

                // Monitoreamos el momento exacto en que el Runtimestandalone toma el control
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return store; },
                  set: function(val) {
                    if (val && typeof val.push === 'function' && val.push !== runtimePush) {
                      runtimePush = makeDualPush(val.push);
                      val.push = runtimePush;
                    }
                    store = val;
                  }
                });
              })();
            `}})}),(0,b.jsx)("body",{className:"min-h-full flex flex-col",children:a})]})},"metadata",0,{title:"Facundo Frosoni - Mi Blog",description:"TP de Virtualización",icons:{icon:"/41816709/api/assets?file=/favicon.ico"}}],27572)},50645,a=>{a.n(a.i(27572))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1gux7cw._.js.map