module.exports=[89578,a=>{a.v({className:"geist_a71539c9-module__T19VSG__className",variable:"geist_a71539c9-module__T19VSG__variable"})},35214,a=>{a.v({className:"geist_mono_8d43a2aa-module__8Li5zG__className",variable:"geist_mono_8d43a2aa-module__8Li5zG__variable"})},27572,a=>{"use strict";var b=a.i(7997),c=a.i(89578);let d={className:c.default.className,style:{fontFamily:"'Geist', 'Geist Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(35214);let f={className:e.default.className,style:{fontFamily:"'Geist Mono', 'Geist Mono Fallback'",fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable),a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"en",className:`${d.variable} ${f.variable} h-full antialiased`,children:[(0,b.jsx)("head",{children:(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:`
              (function() {
                window._flightLogs = [];
                
                // 1. Esp\xeda pasivo para la cola de TURBOPACK
                var targetArray = [];
                var originalRuntimePush = null;
                var turbopackHandler = {
                  get: function(target, prop) {
                    if (prop === 'push') {
                      return function(item) {
                        window._flightLogs.push({
                          timestamp: performance.now(),
                          tipo: 'TURBOPACK.push',
                          argumentos: item ? item.length : 0,
                          scriptSrc: item && item[0] && typeof item[0] === 'object' ? item[0].getAttribute('src') : String(item && item[0]),
                          ids: item ? Array.from(item).slice(1).filter(x => typeof x !== 'function') : []
                        });
                        return originalRuntimePush ? originalRuntimePush(item) : targetArray.push(item);
                      };
                    }
                    return targetArray[prop];
                  },
                  set: function(target, prop, value) {
                    if (prop === 'push') {
                      originalRuntimePush = value;
                      return true;
                    }
                    targetArray[prop] = value;
                    return true;
                  }
                };
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return new Proxy(targetArray, turbopackHandler); },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { globalThis.TURBOPACK.push(x); });
                    }
                  }
                });

                // 2. Esp\xeda pasivo para la cola de streaming __next_f
                var nextFArray = [];
                var nextFHandler = {
                  get: function(target, prop) {
                    if (prop === 'push') {
                      return function(item) {
                        window._flightLogs.push({
                          timestamp: performance.now(),
                          tipo: '__next_f.push',
                          contenidoCorto: JSON.stringify(item).slice(0, 80)
                        });
                        return nextFArray.push(item);
                      };
                    }
                    return nextFArray[prop];
                  },
                  set: function(target, prop, value) {
                    nextFArray[prop] = value;
                    return true;
                  }
                };
                Object.defineProperty(window, '__next_f', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return new Proxy(nextFArray, nextFHandler); },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { window.__next_f.push(x); });
                    }
                  }
                });
              })();
            `}})}),(0,b.jsx)("body",{className:"min-h-full flex flex-col",children:a})]})},"metadata",0,{title:"Facundo Frosoni - Mi Blog",description:"TP de Virtualización",icons:{icon:"/41816709/api/assets?file=/favicon.ico"}}],27572)},50645,a=>{a.n(a.i(27572))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1gux7cw._.js.map