module.exports=[89578,a=>{a.v({className:"geist_a71539c9-module__T19VSG__className",variable:"geist_a71539c9-module__T19VSG__variable"})},35214,a=>{a.v({className:"geist_mono_8d43a2aa-module__8Li5zG__className",variable:"geist_mono_8d43a2aa-module__8Li5zG__variable"})},27572,a=>{"use strict";var b=a.i(7997),c=a.i(89578);let d={className:c.default.className,style:{fontFamily:"'Geist', 'Geist Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(35214);let f={className:e.default.className,style:{fontFamily:"'Geist Mono', 'Geist Mono Fallback'",fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable),a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"en",className:`${d.variable} ${f.variable} h-full antialiased`,children:[(0,b.jsx)("head",{children:(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:`
              (function() {
                // 1. Alinear el Lado de Turbopack: Normalizar la lectura de getAttribute('src')
                var origGetAttribute = HTMLScriptElement.prototype.getAttribute;
                HTMLScriptElement.prototype.getAttribute = function(name) {
                  var val = origGetAttribute.call(this, name);
                  if (name === 'src' && val && val.includes('api/assets?file=')) {
                    try {
                      var url = new URL(val.startsWith('http') ? val : window.location.origin + val);
                      var fileParam = url.searchParams.get('file');
                      if (fileParam) {
                        var cleanPath = fileParam;
                        if (cleanPath.indexOf('/_next/') === 0) cleanPath = cleanPath.substring(7);
                        else if (cleanPath.indexOf('_next/') === 0) cleanPath = cleanPath.substring(6);
                        if (cleanPath.indexOf('/') === 0) cleanPath = cleanPath.substring(1);
                        return cleanPath; // Devuelve 'static/chunks/xxx.js'
                      }
                    } catch(e) {}
                  }
                  return val;
                };

                // 2. Alinear el Lado de React: Interceptar el stream de __next_f antes de que se procese
                var realNextF = [];
                Object.defineProperty(window, '__next_f', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return realNextF; },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(item) { realNextF.push(item); });
                    }
                  }
                });

                var originalNextFPush = realNextF.push;
                realNextF.push = function(item) {
                  if (Array.isArray(item) && typeof item[1] === 'string') {
                    // Reemplazamos la URL absoluta larga por el path relativo limpio
                    item[1] = item[1].split('https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/').join('');
                    item[1] = item[1].split('https://nap.frt.utn.edu.ar/41816709/api/assets?file=').join('');
                  }
                  return originalNextFPush.apply(this, arguments);
                };
              })();
            `}})}),(0,b.jsx)("body",{className:"min-h-full flex flex-col",children:a})]})},"metadata",0,{title:"Facundo Frosoni - Mi Blog",description:"TP de Virtualización",icons:{icon:"/41816709/api/assets?file=/favicon.ico"}}],27572)},50645,a=>{a.n(a.i(27572))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1gux7cw._.js.map