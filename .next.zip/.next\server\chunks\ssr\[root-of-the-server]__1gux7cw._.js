module.exports=[89578,a=>{a.v({className:"geist_a71539c9-module__T19VSG__className",variable:"geist_a71539c9-module__T19VSG__variable"})},35214,a=>{a.v({className:"geist_mono_8d43a2aa-module__8Li5zG__className",variable:"geist_mono_8d43a2aa-module__8Li5zG__variable"})},27572,a=>{"use strict";var b=a.i(7997),c=a.i(89578);let d={className:c.default.className,style:{fontFamily:"'Geist', 'Geist Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(35214);let f={className:e.default.className,style:{fontFamily:"'Geist Mono', 'Geist Mono Fallback'",fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable),a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"en",className:`${d.variable} ${f.variable} h-full antialiased`,children:[(0,b.jsx)("head",{children:(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:`
              (function() {
                // 1. Interceptar propiedad .src nativa de los Scripts
                const srcDescriptor = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
                
                Object.defineProperty(HTMLScriptElement.prototype, 'src', {
                  configurable: true,
                  enumerable: true,
                  get: function() {
                    const realSrc = srcDescriptor.get.call(this);
                    // Si Turbopack lee la URL de la API, le devolvemos el espejismo de la ruta limpia
                    if (realSrc && realSrc.includes('api/assets?file=')) {
                      try {
                        const url = new URL(realSrc);
                        const fileParam = url.searchParams.get('file');
                        if (fileParam) {
                          return window.location.origin + (fileParam.startsWith('/') ? '' : '/') + fileParam;
                        }
                      } catch(e) {}
                    }
                    return realSrc;
                  },
                  set: function(val) {
                    // Si Next.js escribe un nuevo script din\xe1mico limpio, lo camuflamos para el proxy
                    let targetVal = val;
                    if (typeof val === 'string' && val.includes('_next/static/') && !val.includes('api/assets')) {
                      try {
                        const url = new URL(val.startsWith('http') ? val : window.location.origin + val);
                        targetVal = window.location.origin + '/41816709/api/assets?file=' + url.pathname + url.search;
                      } catch(e) {}
                    }
                    srcDescriptor.set.call(this, targetVal);
                  }
                });

                // 2. Interceptar getAttribute y setAttribute para consistencia absoluta de Turbopack
                const originalGet = HTMLScriptElement.prototype.getAttribute;
                HTMLScriptElement.prototype.getAttribute = function(name) {
                  if (name === 'src') {
                    const val = originalGet.call(this, 'src');
                    if (val && val.includes('api/assets?file=')) {
                      try {
                        const abs = val.startsWith('http') ? val : window.location.origin + val;
                        return new URL(abs).searchParams.get('file');
                      } catch(e) {}
                    }
                  }
                  return originalGet.call(this, name);
                };

                const originalSet = HTMLScriptElement.prototype.setAttribute;
                HTMLScriptElement.prototype.setAttribute = function(name, val) {
                  let targetVal = val;
                  if (name === 'src' && typeof val === 'string' && val.includes('_next/static/') && !val.includes('api/assets')) {
                    try {
                      const url = new URL(val.startsWith('http') ? val : window.location.origin + val);
                      targetVal = '/41816709/api/assets?file=' + url.pathname + url.search;
                    } catch(e) {}
                  }
                  originalSet.call(this, name, targetVal);
                };
              })();
            `}})}),(0,b.jsx)("body",{className:"min-h-full flex flex-col",children:a})]})},"metadata",0,{title:"Facundo Frosoni - Mi Blog",description:"TP de Virtualización",icons:{icon:"/41816709/api/assets?file=/favicon.ico"}}],27572)},50645,a=>{a.n(a.i(27572))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1gux7cw._.js.map