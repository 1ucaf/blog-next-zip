module.exports=[89578,a=>{a.v({className:"geist_a71539c9-module__T19VSG__className",variable:"geist_a71539c9-module__T19VSG__variable"})},35214,a=>{a.v({className:"geist_mono_8d43a2aa-module__8Li5zG__className",variable:"geist_mono_8d43a2aa-module__8Li5zG__variable"})},27572,a=>{"use strict";var b=a.i(7997),c=a.i(89578);let d={className:c.default.className,style:{fontFamily:"'Geist', 'Geist Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(35214);let f={className:e.default.className,style:{fontFamily:"'Geist Mono', 'Geist Mono Fallback'",fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable),a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"en",className:`${d.variable} ${f.variable} h-full antialiased`,children:[(0,b.jsx)("head",{children:(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:`
              (function() {
                // 1. Extractor universal a formato relativo estricto (e.g., "static/chunks/xxx.js")
                function toRelativePath(urlStr) {
                  if (!urlStr || typeof urlStr !== 'string') return urlStr;
                  if (urlStr.includes('api/assets?file=')) {
                    try {
                      var url = new URL(urlStr.startsWith('http') ? urlStr : window.location.origin + urlStr);
                      var fileParam = url.searchParams.get('file');
                      if (fileParam) {
                        var p = fileParam;
                        if (p.indexOf('/_next/') === 0) p = p.substring(7);
                        else if (p.indexOf('_next/') === 0) p = p.substring(6);
                        if (p.indexOf('/') === 0) p = p.substring(1);
                        return p;
                      }
                    } catch(e) {}
                  }
                  return urlStr;
                }

                // 2. Normalizar getAttribute('src') para que Turbopack lea el path relativo nativo
                var origGetAttribute = HTMLScriptElement.prototype.getAttribute;
                HTMLScriptElement.prototype.getAttribute = function(name) {
                  var val = origGetAttribute.call(this, name);
                  return (name === 'src' && val) ? toRelativePath(val) : val;
                };

                // 3. Interceptar asignaciones din\xe1micas de scripts futuros (evita 501 en lazy loading)
                var srcDescriptor = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
                Object.defineProperty(HTMLScriptElement.prototype, 'src', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return srcDescriptor.get.call(this); },
                  set: function(val) {
                    var targetVal = val;
                    if (typeof val === 'string' && val.includes('_next/static/') && !val.includes('api/assets')) {
                      try {
                        var urlObj = new URL(val.startsWith('http') ? val : window.location.origin + val);
                        targetVal = window.location.origin + '/41816709/api/assets?file=' + urlObj.pathname + urlObj.search;
                      } catch (e) {}
                    }
                    srcDescriptor.set.call(this, targetVal);
                  }
                });

                // 4. Normalizar el stream de React Flight (__next_f) al formato relativo exacto
                var realNextF = window.__next_f || [];
                function cleanPayload(item) {
                  if (Array.isArray(item) && typeof item[1] === 'string') {
                    var searchLong = 'https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/';
                    var searchRel = '/41816709/api/assets?file=/_next/';
                    item[1] = item[1].split(searchLong).join('');
                    item[1] = item[1].split(searchRel).join('');
                  }
                  return item;
                }

                if (Array.isArray(realNextF)) {
                  for (var i = 0; i < realNextF.length; i++) {
                    cleanPayload(realNextF[i]);
                  }
                }

                var origNextFPush = realNextF.push || Array.prototype.push;
                realNextF.push = function(item) {
                  return origNextFPush.call(this, cleanPayload(item));
                };

                Object.defineProperty(window, '__next_f', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return realNextF; },
                  set: function(val) {
                    if (val && typeof val.push === 'function') {
                      var nativePush = val.push;
                      val.push = function(x) { return nativePush.call(this, cleanPayload(x)); };
                    }
                    realNextF = val;
                  }
                });
              })();
            `}})}),(0,b.jsx)("body",{className:"min-h-full flex flex-col",children:a})]})},"metadata",0,{title:"Facundo Frosoni - Mi Blog",description:"TP de Virtualización",icons:{icon:"/41816709/api/assets?file=/favicon.ico"}}],27572)},50645,a=>{a.n(a.i(27572))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1gux7cw._.js.map