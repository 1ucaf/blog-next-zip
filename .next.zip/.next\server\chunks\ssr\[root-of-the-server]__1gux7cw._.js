module.exports=[89578,a=>{a.v({className:"geist_a71539c9-module__T19VSG__className",variable:"geist_a71539c9-module__T19VSG__variable"})},35214,a=>{a.v({className:"geist_mono_8d43a2aa-module__8Li5zG__className",variable:"geist_mono_8d43a2aa-module__8Li5zG__variable"})},27572,a=>{"use strict";var b=a.i(7997),c=a.i(89578);let d={className:c.default.className,style:{fontFamily:"'Geist', 'Geist Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(35214);let f={className:e.default.className,style:{fontFamily:"'Geist Mono', 'Geist Mono Fallback'",fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable),a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"en",className:`${d.variable} ${f.variable} h-full antialiased`,children:[(0,b.jsx)("head",{children:(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:`
              (function() {
                var store = [];
                var runtimePush = null;

                // Modificador quir\xfargico: convierte los paths relativos de Turbopack en las URLs de la API
                function patchRuntimeManifest(item) {
                  if (Array.isArray(item) && item.length === 2 && item[1] && Array.isArray(item[1].otherChunks)) {
                    item[1].otherChunks = item[1].otherChunks.map(function(chunkPath) {
                      if (chunkPath.indexOf('api/assets') === -1) {
                        return 'https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/' + chunkPath;
                      }
                      return chunkPath;
                    });
                  }
                }

                // Monitorear la cola inicial de carga
                var originalArrayPush = Array.prototype.push;
                store.push = function(item) {
                  patchRuntimeManifest(item);
                  return originalArrayPush.apply(this, arguments);
                };

                // Monitorear el momento en que Next.js toma el control global
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return store; },
                  set: function(val) {
                    if (val && typeof val.push === 'function' && val.push !== runtimePush) {
                      runtimePush = val.push;
                      val.push = function(item) {
                        patchRuntimeManifest(item);
                        return runtimePush.apply(this, arguments);
                      };
                    }
                    if (Array.isArray(val)) {
                      val.forEach(patchRuntimeManifest);
                    }
                    store = val;
                  }
                });
              })();
            `}})}),(0,b.jsx)("body",{className:"min-h-full flex flex-col",children:a})]})},"metadata",0,{title:"Facundo Frosoni - Mi Blog",description:"TP de Virtualización",icons:{icon:"/41816709/api/assets?file=/favicon.ico"}}],27572)},50645,a=>{a.n(a.i(27572))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1gux7cw._.js.map