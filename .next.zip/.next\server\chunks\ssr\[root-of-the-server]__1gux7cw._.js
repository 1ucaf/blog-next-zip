module.exports=[89578,a=>{a.v({className:"geist_a71539c9-module__T19VSG__className",variable:"geist_a71539c9-module__T19VSG__variable"})},35214,a=>{a.v({className:"geist_mono_8d43a2aa-module__8Li5zG__className",variable:"geist_mono_8d43a2aa-module__8Li5zG__variable"})},27572,a=>{"use strict";var b=a.i(7997),c=a.i(89578);let d={className:c.default.className,style:{fontFamily:"'Geist', 'Geist Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(35214);let f={className:e.default.className,style:{fontFamily:"'Geist Mono', 'Geist Mono Fallback'",fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable),a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"es",children:[(0,b.jsx)("head",{children:(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:`
              (function() {
                var targetArray = [];
                var originalRuntimePush = null;

                var handler = {
                  get: function(target, prop) {
                    if (prop === 'push') {
                      return function(item) {
                        // Interceptamos el registro del chunk
                        if (Array.isArray(item) && item[0] && item[0].src) {
                          var src = item[0].src;
                          if (src.includes('api/assets?file=')) {
                            try {
                              var url = new URL(src);
                              var realFile = url.searchParams.get('file');
                              if (realFile) {
                                // Reconstruimos la URL limpia que Next.js/Turbopack espera internamente
                                var realSrc = window.location.origin + (realFile.startsWith('/') ? '' : '/') + realFile;
                                
                                // Clonamos el elemento de script original pero enmascaramos su .src
                                var fakeScript = Object.create(item[0]);
                                Object.defineProperty(fakeScript, 'src', { value: realSrc, enumerable: true });
                                fakeScript.getAttribute = function(name) {
                                  return name === 'src' ? realSrc : item[0].getAttribute(name);
                                };
                                
                                // Reemplazamos el script real por nuestro clon limpio antes de que lo vea Turbopack
                                item[0] = fakeScript;
                              }
                            } catch(e) {}
                          }
                        }
                        // Pasamos el chunk modificado al array original o al runtime de Next si ya inici\xf3
                        return originalRuntimePush ? originalRuntimePush(item) : targetArray.push(item);
                      };
                    }
                    return targetArray[prop];
                  },
                  set: function(target, prop, value) {
                    if (prop === 'push') {
                      // Captura cuando el runtime de Next.js standalone intenta tomar el control del .push
                      originalRuntimePush = value;
                      return true;
                    }
                    targetArray[prop] = value;
                    return true;
                  }
                };

                // Inicializamos el Proxy global fulminante
                var proxy = new Proxy(targetArray, handler);
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return proxy; },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { proxy.push(x); });
                    }
                  }
                });
              })();
            `}})}),(0,b.jsx)("body",{children:a})]})},"metadata",0,{title:"Facundo Frosoni - Mi Blog",description:"TP de Virtualización",icons:{icon:"/41816709/api/assets?file=/favicon.ico"}}],27572)},50645,a=>{a.n(a.i(27572))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1gux7cw._.js.map