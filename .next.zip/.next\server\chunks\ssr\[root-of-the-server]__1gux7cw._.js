module.exports=[89578,a=>{a.v({className:"geist_a71539c9-module__T19VSG__className",variable:"geist_a71539c9-module__T19VSG__variable"})},35214,a=>{a.v({className:"geist_mono_8d43a2aa-module__8Li5zG__className",variable:"geist_mono_8d43a2aa-module__8Li5zG__variable"})},27572,a=>{"use strict";var b=a.i(7997),c=a.i(89578);let d={className:c.default.className,style:{fontFamily:"'Geist', 'Geist Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(35214);let f={className:e.default.className,style:{fontFamily:"'Geist Mono', 'Geist Mono Fallback'",fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable),a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"en",className:`${d.variable} ${f.variable} h-full antialiased`,children:[(0,b.jsx)("head",{children:(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:`
              (function() {
                var currentTurbopack = [];

                // Funci\xf3n central para normalizar la identidad del script antes de que la lea Turbopack
                function interceptPush(originalPush) {
                  return function(item) {
                    if (Array.isArray(item) && item[0] && typeof item[0].getAttribute === 'function') {
                      var realSrc = item[0].getAttribute('src');
                      if (realSrc && realSrc.includes('api/assets?file=')) {
                        try {
                          var url = new URL(realSrc);
                          var fileParam = url.searchParams.get('file');
                          if (fileParam) {
                            // Extraemos el path relativo eliminando el prefijo '_next/' de forma segura
                            var cleanPath = fileParam;
                            if (cleanPath.indexOf('/_next/') === 0) cleanPath = cleanPath.substring(7);
                            else if (cleanPath.indexOf('_next/') === 0) cleanPath = cleanPath.substring(6);
                            if (cleanPath.indexOf('/') === 0) cleanPath = cleanPath.substring(1);

                            // Clonamos el elemento de script y enmascaramos getAttribute para Turbopack
                            var fakeScript = Object.create(item[0]);
                            fakeScript.getAttribute = function(name) {
                              return name === 'src' ? cleanPath : item[0].getAttribute(name);
                            };

                            item[0] = fakeScript;
                          }
                        } catch(e) {}
                      }
                    }
                    return originalPush.apply(this, arguments);
                  };
                }

                // Acoplamos el interceptor a la cola inicial
                currentTurbopack.push = interceptPush(Array.prototype.push);

                // Definimos la propiedad global permitiendo que el Runtime tome el control de forma interactiva
                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() {
                    return currentTurbopack;
                  },
                  set: function(val) {
                    if (val && typeof val.push === 'function') {
                      // El runtime de Next.js tom\xf3 el control: envolvemos su despachador nativo
                      val.push = interceptPush(val.push);
                    }
                    currentTurbopack = val;
                  }
                });
              })();
            `}})}),(0,b.jsx)("body",{className:"min-h-full flex flex-col",children:a})]})},"metadata",0,{title:"Facundo Frosoni - Mi Blog",description:"TP de Virtualización",icons:{icon:"/41816709/api/assets?file=/favicon.ico"}}],27572)},50645,a=>{a.n(a.i(27572))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1gux7cw._.js.map