module.exports=[89578,a=>{a.v({className:"geist_a71539c9-module__T19VSG__className",variable:"geist_a71539c9-module__T19VSG__variable"})},35214,a=>{a.v({className:"geist_mono_8d43a2aa-module__8Li5zG__className",variable:"geist_mono_8d43a2aa-module__8Li5zG__variable"})},27572,a=>{"use strict";var b=a.i(7997),c=a.i(89578);let d={className:c.default.className,style:{fontFamily:"'Geist', 'Geist Fallback'",fontStyle:"normal"}};null!=c.default.variable&&(d.variable=c.default.variable);var e=a.i(35214);let f={className:e.default.className,style:{fontFamily:"'Geist Mono', 'Geist Mono Fallback'",fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable),a.s(["default",0,function({children:a}){return(0,b.jsxs)("html",{lang:"en",className:`${d.variable} ${f.variable} h-full antialiased`,children:[(0,b.jsx)("head",{children:(0,b.jsx)("script",{dangerouslySetInnerHTML:{__html:`
              (function() {
                window._flightLogs = [];
                var targetArray = [];
                var originalRuntimePush = null;

                var turbopackHandler = {
                  get: function(target, prop) {
                    if (prop === 'push') {
                      return function(item) {
                        var logEntry = {
                          timestamp: performance.now(),
                          tipo: 'TURBOPACK.push',
                          rutaOriginal: null,
                          rutaNormalizada: null,
                          statusPush: 'Pendiente',
                          error: null
                        };

                        if (Array.isArray(item) && item[0]) {
                          if (typeof item[0].getAttribute === 'function') {
                            logEntry.rutaOriginal = item[0].getAttribute('src');
                            
                            if (logEntry.rutaOriginal && logEntry.rutaOriginal.includes('api/assets?file=')) {
                              try {
                                var url = new URL(logEntry.rutaOriginal);
                                var fileParam = url.searchParams.get('file');
                                if (fileParam) {
                                  // Normalizaci\xf3n experimental
                                  var cleanPath = fileParam.replace(/^\\/?_next\\//, '');
                                  logEntry.rutaNormalizada = cleanPath;

                                  // Clonamos el elemento de script
                                  var fakeScript = Object.create(item[0]);
                                  fakeScript.getAttribute = function(name) {
                                    return name === 'src' ? cleanPath : item[0].getAttribute(name);
                                  };
                                  
                                  // Aplicamos el cambiazo
                                  item[0] = fakeScript;
                                }
                              } catch(e) {
                                logEntry.error = 'Error en parseo: ' + e.message;
                              }
                            }
                          } else {
                            logEntry.rutaOriginal = 'No es un elemento Script (Posible config/runtime)';
                          }
                        }

                        window._flightLogs.push(logEntry);

                        // Ejecutar el push real y capturar si explota por dentro
                        try {
                          var resultado = originalRuntimePush ? originalRuntimePush(item) : targetArray.push(item);
                          logEntry.statusPush = originalRuntimePush ? 'Procesado por Runtime' : 'Guardado en Cola Inicial';
                          return resultado;
                        } catch(pushError) {
                          logEntry.statusPush = 'CRASHED 💥';
                          logEntry.error = pushError.message;
                          console.error('⚠️ Turbopack nativo rechaz\xf3 el item:', pushError);
                          throw pushError;
                        }
                      };
                    }
                    return targetArray[prop];
                  },
                  set: function(target, prop, value) {
                    if (prop === 'push') {
                      originalRuntimePush = value;
                      return true;
                    }
                    targetArray[prop] = value;
                    return true;
                  }
                };

                Object.defineProperty(globalThis, 'TURBOPACK', {
                  configurable: true,
                  enumerable: true,
                  get: function() { return new Proxy(targetArray, turbopackHandler); },
                  set: function(val) {
                    if (Array.isArray(val)) {
                      val.forEach(function(x) { globalThis.TURBOPACK.push(x); });
                    }
                  }
                });
              })();
            `}})}),(0,b.jsx)("body",{className:"min-h-full flex flex-col",children:a})]})},"metadata",0,{title:"Facundo Frosoni - Mi Blog",description:"TP de Virtualización",icons:{icon:"/41816709/api/assets?file=/favicon.ico"}}],27572)},50645,a=>{a.n(a.i(27572))}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1gux7cw._.js.map