import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: 'standalone',
  basePath: '/41816709',assetPrefix: process.env.NODE_ENV === 'production' 
  ? 'https://nap.frt.utn.edu.ar/41816709/api/assets?file='
  : '',
  serverExternalPackages: ['pg'],
  typescript: {
    ignoreBuildErrors: true,
  },
};

export default nextConfig;
