import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const file = searchParams.get('file'); // Ej: "/_next/static/chunks/3ll07n217cgxf.js"

  if (!file) return new NextResponse('Missing file parameter', { status: 400 });

  // 🛡️ Seguridad (Cybersecurity check): Evitar Path Traversal de alumnos curiosos
  if (!file.startsWith('/_next/static/')) {
    return new NextResponse('Unauthorized path', { status: 403 });
  }

  // Mapear la ruta URL al disco físico del standalone (/var/www/blog/.next/static/...)
  const relativePath = file.replace('/_next', '.next');
  const filePath = path.join(process.cwd(), relativePath);

  if (!fs.existsSync(filePath)) {
    return new NextResponse('File not found', { status: 404 });
  }

  // Leer el archivo binario del disco
  const fileBuffer = fs.readFileSync(filePath);

  // Forzar las cabeceras correctas para que el navegador lo ejecute bien
  let contentType = 'text/plain';
  if (file.endsWith('.js')) contentType = 'application/javascript';
  if (file.endsWith('.css')) contentType = 'text/css';
  if (file.endsWith('.woff2')) contentType = 'font/woff2';

  return new NextResponse(fileBuffer, {
    headers: {
      'Content-Type': contentType,
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  });
}