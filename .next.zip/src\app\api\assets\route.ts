import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const file = searchParams.get('file');

  if (!file) return new NextResponse('Missing file parameter', { status: 400 });

  // 🛡️ Seguridad ampliada: permitimos chunks y el favicon
  const isStatic = file.startsWith('/_next/static/');
  const isFavicon = file === '/favicon.ico' || file === 'favicon.ico';

  if (!isStatic && !isFavicon) {
    return new NextResponse('Unauthorized path', { status: 403 });
  }

  // Resolver ruta física real en el disco del contenedor
  let filePath = '';
  if (isStatic) {
    const relativePath = file.replace('/_next', '.next');
    filePath = path.join(process.cwd(), relativePath);
  } else if (isFavicon) {
    filePath = path.join(process.cwd(), 'public', 'favicon.ico');
  }

  if (!fs.existsSync(filePath)) {
    return new NextResponse('File not found', { status: 404 });
  }

  const fileBuffer = fs.readFileSync(filePath);

  // Forzar Content-Type correcto para el navegador
  let contentType = 'text/plain';
  if (file.endsWith('.js')) contentType = 'application/javascript';
  else if (file.endsWith('.css')) contentType = 'text/css';
  else if (file.endsWith('.woff2')) contentType = 'font/woff2';
  else if (file.endsWith('.ico') || isFavicon) contentType = 'image/x-icon';

  return new NextResponse(fileBuffer, {
    headers: {
      'Content-Type': contentType,
      'Cache-Control': 'public, max-age=31536000, immutable',
    },
  });
}