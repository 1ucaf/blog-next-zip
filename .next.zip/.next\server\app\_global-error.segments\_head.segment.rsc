1:"$Sreact.fragment"
2:I[97367,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"ViewportBoundary"]
3:I[97367,["https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/1d4h-sglyo8ft.js","https://nap.frt.utn.edu.ar/41816709/api/assets?file=/_next/static/chunks/14mumt5_n0xhi.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"lITweaHl2PJojLPT65g-8"}
