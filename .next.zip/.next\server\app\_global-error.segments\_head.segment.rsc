1:"$Sreact.fragment"
2:I[97367,["/41816709/_next/static/chunks/1d4h-sglyo8ft.js","/41816709/_next/static/chunks/14mumt5_n0xhi.js"],"ViewportBoundary"]
3:I[97367,["/41816709/_next/static/chunks/1d4h-sglyo8ft.js","/41816709/_next/static/chunks/14mumt5_n0xhi.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/41816709/_next/static/chunks/1d4h-sglyo8ft.js","/41816709/_next/static/chunks/14mumt5_n0xhi.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/41816709/favicon.ico?favicon.2vob68tjqpejf.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"-RNZRJvnNM3EmsgLCScoy"}
