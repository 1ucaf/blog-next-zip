module.exports=[11893,a=>a.a(async(b,c)=>{try{var d=a.i(22918),e=b([d]);[d]=e.then?(await e)():e,a.s([]),c()}catch(a){c(a)}},!1),32989,a=>a.a(async(b,c)=>{try{var d=a.i(11893),e=a.i(22918),f=b([d,e]);[d,e]=f.then?(await f)():f,a.s(["406c6529e0c17acb8d5ae7ab93569cae24fe84c295",()=>e.createPost]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=_next-internal_server_app_page_actions_0-r165z.js.map