globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/KHrPWPqnZrJ44F_dnHnzJ/_buildManifest.js",
    "static/KHrPWPqnZrJ44F_dnHnzJ/_ssgManifest.js",
    "static/KHrPWPqnZrJ44F_dnHnzJ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3ll07n217cgxf.js",
    "static/chunks/0cbr67yte101v.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/turbopack-3rm-8hzemcm8b.js"
  ]
};
