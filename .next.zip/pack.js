const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🚀 Iniciando empaquetado automático de producción...');

const rootDir = __dirname;
const standaloneDir = path.join(rootDir, '.next', 'standalone');
const githubZipDir = path.join(rootDir, '..', 'github-zip'); // Carpeta del repositorio Git
const zipDestination = path.join(githubZipDir, '.next.zip');

try {
  // 1. Copiar carpetas estáticas obligatorias
  fs.cpSync(path.join(rootDir, 'public'), path.join(standaloneDir, 'public'), { recursive: true, force: true });
  fs.cpSync(path.join(rootDir, '.next', 'static'), path.join(standaloneDir, '.next', 'static'), { recursive: true, force: true });

  // 2. Inyectar módulos físicos de Postgres (Raíz)
  const targetNodeModules = path.join(standaloneDir, 'node_modules');
  if (!fs.existsSync(targetNodeModules)) fs.mkdirSync(targetNodeModules, { recursive: true });

  const pgDeps = ['pg', 'pg-pool', 'pg-protocol', 'pg-types', 'postgres-array', 'postgres-bytea', 'postgres-date', 'postgres-interval'];
  pgDeps.forEach(dep => {
    const src = path.join(rootDir, 'node_modules', dep);
    if (fs.existsSync(src)) fs.cpSync(src, path.join(targetNodeModules, dep), { recursive: true, force: true });
  });

  // 3. Hack Turbopack interno
  const nestedNodeModules = path.join(standaloneDir, '.next', 'node_modules');
  const turbopackHashDir = path.join(nestedNodeModules, 'pg-587764f78a6c7a9c');
  if (!fs.existsSync(nestedNodeModules)) fs.mkdirSync(nestedNodeModules, { recursive: true });
  
  if (fs.existsSync(path.join(rootDir, 'node_modules', 'pg'))) {
    fs.rmSync(turbopackHashDir, { recursive: true, force: true });
    fs.cpSync(path.join(rootDir, 'node_modules', 'pg'), turbopackHashDir, { recursive: true, force: true });
  }
  console.log('✅ Estructura standalone preparada.');

  // 4. COMPRESIÓN AUTOMÁTICA (Usa PowerShell corregido con Set-Location)
  console.log('🤐 Comprimiendo contenido en .next.zip...');
  if (fs.existsSync(zipDestination)) fs.unlinkSync(zipDestination); // Borra el zip viejo si existe
  
  // Nos paramos adentro de standalone y comprimimos el contenido sin mambos de asteriscos
  execSync(`powershell -Command "Set-Location '${standaloneDir}'; Compress-Archive -Path * -DestinationPath '${zipDestination}' -Force"`);
  console.log('📦 Archivo .next.zip generado en github-zip.');

  // 5. GIT AUTOMÁTICO (Add, Commit y Push)
  console.log('🐙 Iniciando subida automática a GitHub...');
  const commitMessage = `Auto-deploy Bypassed Assets: ${new Date().toLocaleString('es-AR')}`;
  
  execSync('git add .', { cwd: githubZipDir });
  execSync(`git commit -m "${commitMessage}"`, { cwd: githubZipDir });
  execSync('git push origin master', { cwd: githubZipDir });
  
  console.log('\n🎉 ¡PROCESO LOCAL COMPLETADO CON ÉXITO! Código en GitHub listo para producción.');

} catch (error) {
  console.error('❌ Error durante el pipeline de automatización:', error);
}